package com.example.noteskeeping.model

class NotesAuthListener(var noteArrayList: ArrayList<Notes>,var status : Boolean, var msg : String = "")

