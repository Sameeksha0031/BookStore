package com.example.noteskeeping.model


data class Notes(var notes : String = "" , var noteId : String =" " , var title : String =""){
}
