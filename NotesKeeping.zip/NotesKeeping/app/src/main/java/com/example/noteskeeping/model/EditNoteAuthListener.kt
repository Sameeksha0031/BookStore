package com.example.noteskeeping.model

class EditNoteAuthListener(var notes : Notes, var status : Boolean, var msg : String="") {
}