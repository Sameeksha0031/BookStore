package com.example.noteskeeping.model

class DialogAuthListener(var user :User ,var  msg : String ,var status : Boolean) {
}