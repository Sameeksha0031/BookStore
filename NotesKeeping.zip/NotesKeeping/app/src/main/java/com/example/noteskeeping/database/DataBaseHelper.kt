package com.example.noteskeeping.database

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.example.noteskeeping.model.User

class DataBaseHelper(context: Context) : SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {

    companion object {
        private val DB_NAME = "NotesDB"
        private val DB_VERSION = 1
        private val TABLE_NAME = "users"
        private val USER_ID = "id"
        private val USERS_NAME = "usersName"
        private val PASSWORD = "password"
        private val PROFILE = "profile"
        private val USEREMAIL = "email"
    }

    override fun onCreate(p0: SQLiteDatabase?) {
        val CREATE_TABLE =
            "CREATE TABLE $TABLE_NAME ($USER_ID String PRIMARY KEY ,$USERS_NAME TEXT,$PASSWORD TEXT," +
                    "$PROFILE TEXT,$USEREMAIL TEXT)"
        p0?.execSQL(CREATE_TABLE)
    }

    override fun onUpgrade(p0: SQLiteDatabase?, p1: Int, p2: Int) {
        val DROP_TABLE = "DROP TABLE IF EXISTS $TABLE_NAME"
        p0?.execSQL(DROP_TABLE)
        onCreate(p0)
    }

    fun getALLUsers(): ArrayList<User> {
        val usersList = ArrayList<User>()
        val db: SQLiteDatabase = writableDatabase
        val selectQuery = "SELECT * FROM $TABLE_NAME"
        val cursor = db.rawQuery(selectQuery, null)
        if (cursor != null) {
            if (cursor.moveToFirst()) {
                do {
                    val users = User(
                        userId = cursor.getColumnIndex(USER_ID).toString(),
                        userName = cursor.getColumnIndex(
                            USERS_NAME
                        ).toString(),
                        email = cursor.getColumnIndex(USEREMAIL).toString(),
                        password =
                        cursor.getColumnIndex(PASSWORD).toString(),
                        profile = cursor.getColumnIndex(
                            PROFILE
                        ).toString()
                    )
                    usersList.add(users)
                } while (cursor.moveToLast())
            }
        }
        cursor.close()
        return usersList
    }

    fun addUsers(user: User): Boolean {
        val db: SQLiteDatabase = this.writableDatabase
        val values = ContentValues()
        values.put(USER_ID, user.userId)
        values.put(USERS_NAME, user.userName)
        values.put(USEREMAIL, user.email)
        values.put(PASSWORD, user.password)
        values.put(PROFILE, user.profile)
        val _success: Long = db.insert(TABLE_NAME, null, values)
        db.close()
        return (Integer.parseInt("$_success") != -1)
    }

    fun getSingleUser(userId: String): User {
        // var user = User(userId, userName = "", email = "", password = "", profile = "")
        val db: SQLiteDatabase = writableDatabase
        val selectQuery = "SELECT * FROM $TABLE_NAME WHERE $USER_ID = $userId"
        val cursor = db.rawQuery(selectQuery, null)
        cursor?.moveToFirst()
        val users = User(
            userId = cursor.getColumnIndex(USER_ID).toString(), userName = cursor.getColumnIndex(
                USERS_NAME
            ).toString(), email = cursor.getColumnIndex(USEREMAIL).toString(), password =
            cursor.getColumnIndex(PASSWORD).toString(), profile = cursor.getColumnIndex(
                PROFILE
            ).toString()
        )
        cursor.close()
        return users
    }

    fun deleteUser(userId: String): Boolean {
        val db : SQLiteDatabase = this.writableDatabase
        val _success = db.delete(TABLE_NAME, USER_ID +"=?", arrayOf(userId.toString())).toLong()
        db.close()
        return _success.toInt() != -1
    }

    fun updateTask(user : User): Boolean{
        val db: SQLiteDatabase = writableDatabase
        val values = ContentValues()
        values.put(USER_ID, user.userId)
        values.put(USERS_NAME, user.userName)
        values.put(USEREMAIL, user.email)
        values.put(PASSWORD, user.password)
        values.put(PROFILE, user.profile)
        val _success : Long = db.update(TABLE_NAME,values,user.userId + "=?", arrayOf(user.userId.toString())).toLong()
        db.close()
        return _success.toInt() != -1
    }
}