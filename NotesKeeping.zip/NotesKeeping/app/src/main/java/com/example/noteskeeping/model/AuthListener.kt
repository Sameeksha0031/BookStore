package com.example.noteskeeping.model

data class AuthListener(var status : Boolean, var msg : String){

}
