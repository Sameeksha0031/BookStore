package com.example.noteskeeping.model

data class User(var userId : String = "", var userName : String, var email : String , var password : String,var profile : String ){
}
