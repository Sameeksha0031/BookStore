package com.example.noteskeeping.model

import android.util.Log
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.example.noteskeeping.view.NoteRecyclerViewAdapter
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.*
import com.google.firebase.firestore.EventListener
import com.google.firebase.firestore.ktx.toObject
import com.google.firebase.storage.FirebaseStorage
import java.util.*
import kotlin.collections.ArrayList
import kotlin.collections.HashMap

class NoteServices() {
    private lateinit var auth: FirebaseAuth
    private lateinit var firebaseFireStore: FirebaseFirestore
    private var firebaseStore: FirebaseStorage? = null

    init {
        noteInitServices()
    }

    private fun noteInitServices() {
        auth = FirebaseAuth.getInstance()
        firebaseFireStore = FirebaseFirestore.getInstance()
        firebaseStore = FirebaseStorage.getInstance()
    }

    fun writeNotes(
        note: Notes,
        listener: (AuthListener) -> Unit
    ) {                     ////UUID.randomUUID().toString()
        val userID = auth.currentUser?.uid
        val noteID = UUID.randomUUID().toString()
        val noteHashMap = HashMap<String, String>()
        if (userID != null) {
            noteHashMap["NoteID"] = noteID
            noteHashMap["Title"] = note.title
            noteHashMap["Note"] = note.notes
            firebaseFireStore.collection("users").document(userID).collection("Notes")
                .document(noteID)
                .set(noteHashMap)
                .addOnSuccessListener {
                    listener(AuthListener(true, "note update"))
                }
        }
    }

    fun readNotes(listener: (NotesAuthListener) -> Unit) {
        val userID = auth.currentUser?.uid
        var notesList = ArrayList<Notes>()
        if (userID != null) {
            firebaseFireStore.collection("users").document(userID)
                .collection("Notes")
                .get()
                .addOnSuccessListener {
                    if (it != null) {
                        for (doc in it.documents) {
                            var noteContent: String = doc["Note"].toString()
                            var noteId: String = doc["NoteID"].toString()
                            var noteTitle: String = doc["Title"].toString()
                            var notes =
                                Notes(notes = noteContent, noteId = noteId, title = noteTitle)
                            notesList.add(notes!!)
                        }
                        Log.d("NoteService", "${notesList.size.toString()}")

                        for (note in notesList) {

                            Log.d("NoteService", "Title is ${note.title}")
                        }
                    }
                    listener(NotesAuthListener(notesList, true, "Data added successfully"))
                }
        }
    }

    fun deleteNote(noteId: String, listener: (AuthListener) -> Unit) {
        val userID = auth.currentUser?.uid
        if (userID != null) {
            firebaseFireStore.collection("users").document(userID)
                .collection("Notes").document(noteId).delete()
                .addOnCompleteListener {
                    if (it.isSuccessful) {
                        listener(AuthListener(true, "User deleted successfully"))
                    }
                }
        }
    }

    fun readSingleNote(noteId: String, listener: (EditNoteAuthListener) -> Unit) {
        val userID = auth.currentUser?.uid.toString()
        if (userID != null) {
            firebaseFireStore.collection("users").document(userID)
                .collection("Notes").document(noteId).get()
                .addOnCompleteListener {
                    if (it.isSuccessful) {
                        var note = Notes(
                            noteId = it.result.getString("NoteID").toString(),
                            title = it.result.getString("Title").toString(),
                            notes = it.result.getString("Note").toString()
                        )
                        listener(EditNoteAuthListener(note, true, "success"))
                    }
                }
        }

    }

    fun updateSingleNote(note: Notes, noteId: String, listener: (AuthListener) -> Unit) {
        val userID = auth.currentUser?.uid.toString()
        val noteHashMap = HashMap<String, String>()
        noteHashMap["Note"] = note.notes
        noteHashMap["NoteID"] = note.noteId
        noteHashMap["Title"] = note.title
        firebaseFireStore.collection("users").document(userID).collection("Notes")
            .document(noteId)
            .set(noteHashMap)
            .addOnSuccessListener {
                listener(AuthListener(true, "note update"))
            }
    }

}

